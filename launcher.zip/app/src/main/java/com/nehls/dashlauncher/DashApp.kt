package com.nehls.dashlauncher

import android.graphics.Rect
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Umbrella
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun DashApp(ui: UiState, location: LocationRepository, media: MediaRepository, actions: DashActions) {
    val now by produceState(initialValue = System.currentTimeMillis()) {
        while (true) {
            delay(1000L)
            value = System.currentTimeMillis()
        }
    }
    val hour = Calendar.getInstance().apply { timeInMillis = now }.get(Calendar.HOUR_OF_DAY)
    val isDark = when (ui.themeMode.value) {
        "light" -> false
        "auto" -> hour < 7 || hour >= 19
        else -> true
    }
    val loc by location.location.collectAsState()
    val nowPlaying by media.state.collectAsState()

    // GPS speed, hidden if the last fix is stale (no GPS hardware, tunnel, etc.)
    val speedMph: Int? = loc?.let { l ->
        if (l.hasSpeed() && now - l.time < 10_000) (l.speed * 2.23694f).roundToInt() else null
    }

    var weather by remember { mutableStateOf<Weather?>(null) }
    val weatherKey = loc?.let { String.format(Locale.US, "%.1f,%.1f", it.latitude, it.longitude) }
    LaunchedEffect(weatherKey) {
        val l = loc ?: return@LaunchedEffect
        while (true) {
            WeatherRepository.fetch(l.latitude, l.longitude)?.let { weather = it }
            delay(15 * 60 * 1000L)
        }
    }

    CompositionLocalProvider(LocalDash provides if (isDark) DarkColors else LightColors) {
        HomeScreen(
            ui = ui,
            actions = actions,
            media = media,
            now = now,
            speedMph = speedMph,
            weather = weather,
            nowPlaying = nowPlaying,
        )
    }
}

@Composable
fun HomeScreen(
    ui: UiState,
    actions: DashActions,
    media: MediaRepository,
    now: Long,
    speedMph: Int?,
    weather: Weather?,
    nowPlaying: NowPlaying?,
) {
    val c = LocalDash.current
    var recenter by remember { mutableIntStateOf(0) }

    BoxWithConstraints(Modifier.fillMaxSize().background(c.bg)) {
        val landscape = maxWidth >= maxHeight
        Column(Modifier.fillMaxSize()) {
            if (landscape) {
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    VehiclePanel(Modifier.fillMaxHeight().weight(0.33f), speedMph)
                    MapArea(
                        modifier = Modifier.fillMaxHeight().weight(0.67f).padding(top = 12.dp, end = 12.dp),
                        ui = ui, actions = actions, media = media, now = now,
                        weather = weather, nowPlaying = nowPlaying,
                        recenterSignal = recenter, onRecenter = { recenter++ },
                    )
                }
            } else {
                Column(Modifier.weight(1f).fillMaxWidth()) {
                    VehiclePanel(Modifier.fillMaxWidth().weight(0.42f), speedMph)
                    MapArea(
                        modifier = Modifier.fillMaxWidth().weight(0.58f).padding(horizontal = 12.dp),
                        ui = ui, actions = actions, media = media, now = now,
                        weather = weather, nowPlaying = nowPlaying,
                        recenterSignal = recenter, onRecenter = { recenter++ },
                    )
                }
            }
            Dock(
                apps = ui.apps.value,
                pinned = ui.pinned.value,
                actions = actions,
                onOpenApps = { ui.settingsOpen.value = false; ui.drawerOpen.value = true },
                onOpenSettings = { ui.drawerOpen.value = false; ui.settingsOpen.value = true },
            )
        }

        if (ui.drawerOpen.value) {
            AppDrawer(
                apps = ui.apps.value,
                pinned = ui.pinned.value,
                actions = actions,
                onClose = { ui.drawerOpen.value = false },
            )
        }
        if (ui.settingsOpen.value) {
            SettingsSheet(
                themeMode = ui.themeMode.value,
                mediaAccess = ui.mediaAccess.value,
                hasLocation = ui.hasLocation.value,
                windowMode = ui.windowMode.value,
                actions = actions,
                onClose = { ui.settingsOpen.value = false },
            )
        }
    }
}

/* ---------- Left: vehicle panel ---------- */

@Composable
fun VehiclePanel(modifier: Modifier, speedMph: Int?) {
    val c = LocalDash.current
    Column(
        modifier.padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = speedMph?.toString() ?: "--",
            color = c.text,
            fontSize = 76.sp,
            lineHeight = 80.sp,
            fontWeight = FontWeight.Light,
        )
        Text("mph", color = c.textDim, fontSize = 15.sp)

        TruckGraphic(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(vertical = 10.dp),
        )

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatTile(Modifier.weight(1f), "Engine", null, "rpm")
            StatTile(Modifier.weight(1f), "Coolant", null, "°F")
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatTile(Modifier.weight(1f), "Battery", null, "V")
            StatTile(Modifier.weight(1f), "Fuel", null, "%")
        }
        Spacer(Modifier.height(8.dp))
        Text("Plug in an OBD adapter to see truck data", color = c.textDim, fontSize = 11.sp)
    }
}

@Composable
fun StatTile(modifier: Modifier, label: String, value: String?, unit: String) {
    val c = LocalDash.current
    Column(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(c.panel)
            .padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
        Text(label, color = c.textDim, fontSize = 11.sp)
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value ?: "--", color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.width(4.dp))
            Text(unit, color = c.textDim, fontSize = 12.sp, modifier = Modifier.padding(bottom = 3.dp))
        }
    }
}

/* ---------- Right: map with overlays ---------- */

@Composable
fun MapArea(
    modifier: Modifier,
    ui: UiState,
    actions: DashActions,
    media: MediaRepository,
    now: Long,
    weather: Weather?,
    nowPlaying: NowPlaying?,
    recenterSignal: Int,
    onRecenter: () -> Unit,
) {
    val c = LocalDash.current
    BoxWithConstraints(
        modifier
            .onGloballyPositioned { coords ->
                // Remember where the map sits so apps can open in a window right over it.
                val b = coords.boundsInWindow()
                val r = Rect(b.left.toInt(), b.top.toInt(), b.right.toInt(), b.bottom.toInt())
                if (r.width() > 0 && r != ui.mapBounds.value) ui.mapBounds.value = r
            }
            .clip(RoundedCornerShape(18.dp))
            .background(c.panelAlt),
    ) {
        val searchWidth: Dp = minOf(maxWidth * 0.55f, 380.dp)
        val mediaWidth: Dp = minOf(maxWidth * 0.62f, 400.dp)

        DashMap(
            modifier = Modifier.fillMaxSize(),
            isDark = c.isDark,
            hasLocation = ui.hasLocation.value,
            recenterSignal = recenterSignal,
        )

        Row(
            Modifier
                .fillMaxWidth()
                .align(Alignment.TopStart)
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            NavigateBox(Modifier.width(searchWidth))
            Spacer(Modifier.weight(1f))
            StatusChip(now, weather)
        }

        MediaCard(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(14.dp)
                .width(mediaWidth),
            np = nowPlaying,
            hasAccess = ui.mediaAccess.value,
            appleMusic = ui.apps.value.firstOrNull { it.component.packageName == APPLE_MUSIC },
            appsLoaded = ui.apps.value.isNotEmpty(),
            actions = actions,
            media = media,
        )

        if (ui.hasLocation.value) {
            RoundButton(
                icon = Icons.Filled.MyLocation,
                modifier = Modifier.align(Alignment.BottomEnd).padding(14.dp),
                onClick = onRecenter,
            )
        } else {
            Text(
                "Allow location",
                color = c.text,
                fontSize = 14.sp,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(14.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(c.panel)
                    .clickable { actions.requestLocation() }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
            )
        }

        Text(
            "© OpenStreetMap contributors © CARTO",
            color = c.textDim,
            fontSize = 9.sp,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 2.dp),
        )
    }
}

@Composable
fun NavigateBox(modifier: Modifier) {
    val c = LocalDash.current
    val context = LocalContext.current
    val focus = LocalFocusManager.current
    var query by remember { mutableStateOf("") }

    fun go() {
        if (query.isNotBlank()) {
            DashIntents.navigate(context, query.trim())
            query = ""
        }
        focus.clearFocus()
    }

    Row(
        modifier
            .height(50.dp)
            .clip(RoundedCornerShape(25.dp))
            .background(c.panel)
            .padding(start = 16.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Search, contentDescription = null, tint = c.textDim, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (query.isEmpty()) Text("Navigate", color = c.textDim, fontSize = 17.sp)
            BasicTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                textStyle = TextStyle(color = c.text, fontSize = 17.sp),
                cursorBrush = SolidColor(c.accent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { go() }),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        if (query.isNotEmpty()) {
            Icon(
                Icons.Filled.Close,
                contentDescription = "Clear",
                tint = c.textDim,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .clickable { query = "" }
                    .padding(8.dp),
            )
        }
    }
}

@Composable
fun StatusChip(now: Long, weather: Weather?) {
    val c = LocalDash.current
    val timeFmt = remember { SimpleDateFormat("h:mm", Locale.US) }
    val ampmFmt = remember { SimpleDateFormat("a", Locale.US) }
    Row(
        Modifier
            .height(50.dp)
            .clip(RoundedCornerShape(25.dp))
            .background(c.panel)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(timeFmt.format(Date(now)), color = c.text, fontSize = 19.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.width(4.dp))
        Text(ampmFmt.format(Date(now)), color = c.textDim, fontSize = 13.sp)
        if (weather != null) {
            Spacer(Modifier.width(16.dp))
            Icon(weatherIcon(weather), contentDescription = null, tint = c.text, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(6.dp))
            Text("${weather.tempF}°", color = c.text, fontSize = 19.sp)
        }
    }
}

fun weatherIcon(w: Weather): ImageVector = when (w.code) {
    0, 1 -> if (w.isDay) Icons.Filled.WbSunny else Icons.Filled.NightsStay
    2, 3, 45, 48 -> Icons.Filled.Cloud
    in 51..67, in 80..82 -> Icons.Filled.Umbrella
    in 71..77, 85, 86 -> Icons.Filled.AcUnit
    in 95..99 -> Icons.Filled.FlashOn
    else -> Icons.Filled.Cloud
}

@Composable
fun MediaCard(
    modifier: Modifier,
    np: NowPlaying?,
    hasAccess: Boolean,
    appleMusic: AppEntry?,
    appsLoaded: Boolean,
    actions: DashActions,
    media: MediaRepository,
) {
    val c = LocalDash.current
    val context = LocalContext.current
    val art = remember(np?.art) { np?.art?.asImageBitmap() }
    val installed = appleMusic != null || !appsLoaded

    val title = np?.title ?: "Apple Music"
    val subtitle = when {
        np != null -> np.artist ?: ""
        !installed -> "Install Apple Music to play here"
        !hasAccess -> "Turn on song info in settings"
        else -> "Tap to open your library"
    }

    Row(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(c.panel)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(if (art == null) Color(0xFFFA2D48) else c.panelAlt),
            contentAlignment = Alignment.Center,
        ) {
            if (art != null) {
                Image(art, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            } else {
                Icon(Icons.Filled.MusicNote, contentDescription = null, tint = Color.White)
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(
            Modifier
                .weight(1f)
                .clickable {
                    when {
                        appleMusic != null -> actions.openApp(appleMusic, false)
                        appsLoaded -> DashIntents.openStore(context, APPLE_MUSIC)
                    }
                },
        ) {
            Text(
                title,
                color = c.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(
                subtitle,
                color = c.textDim, fontSize = 13.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        MediaButton(Icons.Filled.SkipPrevious) { media.previous() }
        MediaButton(if (np?.isPlaying == true) Icons.Filled.Pause else Icons.Filled.PlayArrow) { media.playPause() }
        MediaButton(Icons.Filled.SkipNext) { media.next() }
    }
}

@Composable
fun MediaButton(icon: ImageVector, onClick: () -> Unit) {
    val c = LocalDash.current
    Box(
        Modifier
            .size(46.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = null, tint = c.text, modifier = Modifier.size(28.dp))
    }
}

@Composable
fun RoundButton(icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = LocalDash.current
    Box(
        modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(c.panel)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = null, tint = c.text, modifier = Modifier.size(24.dp))
    }
}

/* ---------- Bottom dock ---------- */

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Dock(
    apps: List<AppEntry>,
    pinned: List<String>,
    actions: DashActions,
    onOpenApps: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val context = LocalContext.current
    val pinnedApps = remember(apps, pinned) {
        pinned.mapNotNull { key -> apps.firstOrNull { it.key == key } }
    }

    Row(
        Modifier
            .fillMaxWidth()
            .height(78.dp)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RoundButton(Icons.Filled.Apps, onClick = onOpenApps)
        LazyRow(
            Modifier
                .weight(1f)
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(22.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            items(pinnedApps, key = { it.key }) { app ->
                Image(
                    bitmap = app.icon,
                    contentDescription = app.label,
                    modifier = Modifier
                        .size(50.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .combinedClickable(
                            onClick = { actions.openApp(app, false) },      // window over the map
                            onLongClick = { actions.openApp(app, true) },   // full screen
                        ),
                )
            }
        }
        RoundButton(Icons.Filled.VolumeDown, onClick = { DashIntents.volume(context, false) })
        Spacer(Modifier.width(10.dp))
        RoundButton(Icons.Filled.VolumeUp, onClick = { DashIntents.volume(context, true) })
        Spacer(Modifier.width(10.dp))
        RoundButton(Icons.Filled.Settings, onClick = onOpenSettings)
    }
}
