package com.nehls.dashlauncher

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Dim backdrop that closes the panel when tapped outside it. */
@Composable
private fun Scrim(onClose: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.6f))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() },
        contentAlignment = Alignment.Center,
    ) {
        content()
    }
}

/** Swallows taps so touching the panel itself doesn't close it. */
private fun Modifier.blockTaps(): Modifier = this.then(
    Modifier.clickable(interactionSource = MutableInteractionSource(), indication = null) {},
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppDrawer(apps: List<AppEntry>, pinned: List<String>, actions: DashActions, onClose: () -> Unit) {
    val c = LocalDash.current
    var query by remember { mutableStateOf("") }
    val filtered = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }

    Scrim(onClose) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(20.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(c.bg)
                .blockTaps()
                .padding(20.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(
                    Modifier
                        .weight(1f)
                        .height(50.dp)
                        .clip(RoundedCornerShape(25.dp))
                        .background(c.panel)
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.Search, contentDescription = null, tint = c.textDim, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(10.dp))
                    Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                        if (query.isEmpty()) Text("Search apps", color = c.textDim, fontSize = 17.sp)
                        BasicTextField(
                            value = query,
                            onValueChange = { query = it },
                            singleLine = true,
                            textStyle = TextStyle(color = c.text, fontSize = 17.sp),
                            cursorBrush = SolidColor(c.accent),
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                Spacer(Modifier.width(12.dp))
                RoundButton(Icons.Filled.Close, onClick = onClose)
            }
            Text(
                "Tap to open over the map. Press and hold for full screen or to change the dock.",
                color = c.textDim,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 12.dp, bottom = 4.dp, start = 4.dp),
            )
            LazyVerticalGrid(
                columns = GridCells.Adaptive(108.dp),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(vertical = 8.dp),
            ) {
                items(filtered, key = { it.key }) { app ->
                    val isPinned = app.key in pinned
                    var menuOpen by remember { mutableStateOf(false) }
                    Box {
                    Column(
                        Modifier
                            .padding(6.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .combinedClickable(
                                onClick = { actions.openApp(app, false) },
                                onLongClick = { menuOpen = true },
                            )
                            .padding(vertical = 10.dp, horizontal = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Box {
                            Image(app.icon, contentDescription = null, modifier = Modifier.size(58.dp))
                            if (isPinned) {
                                Box(
                                    Modifier
                                        .align(Alignment.TopEnd)
                                        .offset(x = 6.dp, y = (-6).dp)
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(c.accent),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Icon(Icons.Filled.PushPin, contentDescription = "In dock", tint = Color.White, modifier = Modifier.size(13.dp))
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            app.label,
                            color = c.text,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Open full screen") },
                            onClick = {
                                menuOpen = false
                                actions.openApp(app, true)
                            },
                        )
                        DropdownMenuItem(
                            text = { Text(if (isPinned) "Remove from dock" else "Add to dock") },
                            onClick = {
                                menuOpen = false
                                actions.togglePin(app.key)
                            },
                        )
                    }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsSheet(ui: UiState, actions: DashActions, onClose: () -> Unit) {
    val c = LocalDash.current
    val context = LocalContext.current
    val version = remember { DashIntents.versionName(context) }

    Scrim(onClose) {
        Column(
            Modifier
                .widthIn(max = 600.dp)
                .fillMaxWidth()
                .padding(20.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(c.bg)
                .blockTaps()
                .verticalScroll(rememberScrollState())
                .padding(22.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Settings", color = c.text, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                RoundButton(Icons.Filled.Close, onClick = onClose)
            }

            SectionTitle("Screen theme")
            Segmented(
                options = listOf("dark" to "Dark", "light" to "Light", "auto" to "Auto (sunset)"),
                selected = ui.themeMode.value,
                onSelect = actions.setTheme,
            )

            SectionTitle("Map style")
            Segmented(
                options = listOf("standard" to "Standard", "satellite" to "Satellite", "mars" to "Mars"),
                selected = ui.mapStyle.value,
                onSelect = actions.setMapStyle,
            )

            SectionTitle("Dock icons")
            Segmented(
                options = listOf("simple" to "Simple glyphs", "original" to "App colors"),
                selected = ui.dockStyle.value,
                onSelect = actions.setDockStyle,
            )

            Spacer(Modifier.height(6.dp))
            SettingRow(
                title = "Dim at night",
                detail = if (ui.dimAtNight.value) "On: darkens the dashboard after sunset" else "Off",
                button = if (ui.dimAtNight.value) "Turn off" else "Turn on",
            ) { actions.setDimAtNight(!ui.dimAtNight.value) }
            SettingRow(
                title = "Calendar card",
                detail = if (ui.hasCalendar.value) "On: shows your next event under Navigate"
                else "Shows your next event from the box's Google account",
                button = if (ui.hasCalendar.value) null else "Allow",
            ) { actions.requestCalendar() }
            SettingRow(
                title = "Apple Music song info",
                detail = if (ui.mediaAccess.value) "On" else "Needs notification access for Dash Launcher",
                button = if (ui.mediaAccess.value) null else "Turn on",
            ) { DashIntents.openNotificationAccess(context) }
            SettingRow(
                title = "Location",
                detail = if (ui.hasLocation.value) "Allowed" else "Needed for the map, speed, speed limits and weather",
                button = if (ui.hasLocation.value) null else "Allow",
            ) { actions.requestLocation() }
            SettingRow(
                title = "Open at startup",
                detail = "Choose Dash Launcher as the Home app",
                button = "Choose",
            ) { DashIntents.openHomeSettings(context) }
            SettingRow(
                title = "Android settings",
                detail = "Wi-Fi, Bluetooth, date & time and system options",
                button = "Open",
            ) { DashIntents.openSystemSettings(context) }
            SettingRow(
                title = "Truck data (OBD-II)",
                detail = "Coming once the OBDLink adapter is connected",
                button = null,
            ) {}

            Spacer(Modifier.height(14.dp))
            Text(
                "Dash Launcher $version · Map data © OpenStreetMap contributors · Satellite imagery: USGS",
                color = c.textDim,
                fontSize = 12.sp,
            )
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    val c = LocalDash.current
    Spacer(Modifier.height(18.dp))
    Text(text, color = c.text, fontSize = 16.sp)
    Spacer(Modifier.height(10.dp))
}

@Composable
private fun Segmented(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    val c = LocalDash.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(c.panel)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        options.forEach { (key, label) ->
            val isSelected = selected == key
            Text(
                label,
                color = if (isSelected) Color.White else c.text,
                fontSize = 15.sp,
                textAlign = TextAlign.Center,
                maxLines = 1,
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isSelected) c.accent else Color.Transparent)
                    .clickable { onSelect(key) }
                    .padding(vertical = 12.dp),
            )
        }
    }
}

@Composable
private fun SettingRow(title: String, detail: String, button: String?, onClick: () -> Unit) {
    val c = LocalDash.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 10.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(c.panel)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = c.text, fontSize = 16.sp)
            Text(detail, color = c.textDim, fontSize = 13.sp)
        }
        if (button != null) {
            Spacer(Modifier.width(12.dp))
            Text(
                button,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(c.accent)
                    .clickable(onClick = onClick)
                    .padding(horizontal = 18.dp, vertical = 10.dp),
            )
        }
    }
}
