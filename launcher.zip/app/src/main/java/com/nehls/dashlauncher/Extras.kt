package com.nehls.dashlauncher

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Event
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/* ---------- Speed limit sign (US style) ---------- */

@Composable
fun SpeedLimitSign(mph: Int) {
    Column(
        Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color.White)
            .padding(3.dp)
            .border(2.dp, Color.Black, RoundedCornerShape(6.dp))
            .padding(horizontal = 9.dp, vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("SPEED", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold, lineHeight = 10.sp)
        Text("LIMIT", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold, lineHeight = 10.sp)
        Text(mph.toString(), color = Color.Black, fontSize = 28.sp, fontWeight = FontWeight.Bold, lineHeight = 30.sp)
    }
}

/* ---------- Next calendar event ---------- */

@Composable
fun CalendarCard(modifier: Modifier, event: CalendarEvent, now: Long) {
    val c = LocalDash.current
    val context = LocalContext.current
    val timeFmt = remember { SimpleDateFormat("h:mm a", Locale.US) }
    val minutes = ((event.begin - now) / 60_000L).toInt()
    val whenText = when {
        event.begin <= now -> "Now · until ${timeFmt.format(Date(event.end))}"
        minutes < 60 -> "${timeFmt.format(Date(event.begin))} · in $minutes min"
        else -> timeFmt.format(Date(event.begin))
    }

    Row(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(c.panel)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Event, contentDescription = null, tint = c.accent, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(event.title, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(whenText, color = c.textDim, fontSize = 13.sp, maxLines = 1)
            event.location?.let {
                Text(it, color = c.textDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        event.location?.let { place ->
            Spacer(Modifier.width(10.dp))
            Text(
                "Navigate",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .background(c.accent)
                    .clickable { DashIntents.navigate(context, place) }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            )
        }
    }
}

/* ---------- Forecast ---------- */

@Composable
fun ForecastSheet(weather: Weather?, onClose: () -> Unit) {
    val c = LocalDash.current
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.6f))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier
                .widthIn(max = 760.dp)
                .fillMaxWidth()
                .padding(20.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(c.bg)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                .verticalScroll(rememberScrollState())
                .padding(22.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Weather", color = c.text, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                if (weather != null) {
                    Spacer(Modifier.width(14.dp))
                    Icon(weatherIconFor(weather.code, weather.isDay), contentDescription = null, tint = c.text, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("${weather.tempF}°", color = c.text, fontSize = 24.sp)
                }
                Spacer(Modifier.weight(1f))
                RoundButton(Icons.Filled.Close, onClick = onClose)
            }
            if (weather == null || weather.hourly.isEmpty()) {
                Spacer(Modifier.height(16.dp))
                Text("Forecast loads once the box has a location and internet.", color = c.textDim, fontSize = 15.sp)
            } else {
                ForecastBody(weather)
            }
        }
    }
}

@Composable
private fun ForecastBody(weather: Weather) {
    val c = LocalDash.current
    Column {
            Spacer(Modifier.height(18.dp))
            Text("Next 12 hours", color = c.textDim, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                weather.hourly.forEach { h ->
                    Column(
                        Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(c.panel)
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(h.label, color = c.textDim, fontSize = 12.sp)
                        Spacer(Modifier.height(6.dp))
                        Icon(weatherIconFor(h.code, h.isDay), contentDescription = null, tint = c.text, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.height(6.dp))
                        Text("${h.tempF}°", color = c.text, fontSize = 17.sp)
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Text("Next few days", color = c.textDim, fontSize = 13.sp)
            weather.daily.forEach { d ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(c.panel)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(d.label, color = c.text, fontSize = 16.sp, modifier = Modifier.width(70.dp))
                    Icon(weatherIconFor(d.code, true), contentDescription = null, tint = c.text, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(12.dp))
                    Text(if (d.rainPct > 0) "${d.rainPct}% rain" else "", color = c.textDim, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Text("${d.hiF}°", color = c.text, fontSize = 17.sp)
                    Spacer(Modifier.width(10.dp))
                    Text("${d.loF}°", color = c.textDim, fontSize = 17.sp)
                }
            }
    }
}

/* ---------- Startup animation (plays when the launcher starts with the box) ---------- */

object Session {
    var splashShown = false
}

@Composable
fun BootSplash(onDone: () -> Unit) {
    val truckAlpha = remember { Animatable(0f) }
    val truckScale = remember { Animatable(0.82f) }
    val glow = remember { Animatable(0f) }
    val textAlpha = remember { Animatable(0f) }
    val greeting = remember {
        when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
            in 4..11 -> "Good morning"
            in 12..16 -> "Good afternoon"
            else -> "Good evening"
        }
    }

    LaunchedEffect(Unit) {
        launch { truckScale.animateTo(1f, tween(1500, easing = FastOutSlowInEasing)) }
        truckAlpha.animateTo(1f, tween(900))
        launch { glow.animateTo(1f, tween(500)) }
        textAlpha.animateTo(1f, tween(600))
        delay(1100)
        onDone()
    }

    CompositionLocalProvider(LocalDash provides DarkColors) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onDone() },
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(contentAlignment = Alignment.Center) {
                    Box(
                        Modifier
                            .size(260.dp)
                            .graphicsLayer { alpha = glow.value }
                            .clip(RoundedCornerShape(130.dp))
                            .background(
                                androidx.compose.ui.graphics.Brush.radialGradient(
                                    listOf(Color(0xFF3E6AE1).copy(alpha = 0.35f), Color.Transparent),
                                ),
                            ),
                    )
                    TruckGraphic(
                        Modifier
                            .size(220.dp)
                            .graphicsLayer {
                                alpha = truckAlpha.value
                                scaleX = truckScale.value
                                scaleY = truckScale.value
                            },
                    )
                }
                Spacer(Modifier.height(18.dp))
                Text(
                    greeting,
                    color = Color(0xFFF2F3F5),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Light,
                    modifier = Modifier.graphicsLayer { alpha = textAlpha.value },
                )
            }
        }
    }
}
