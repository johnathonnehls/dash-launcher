package com.nehls.dashlauncher

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.roundToInt

/* ---------- Speed limit (OpenStreetMap road data via the Overpass API) ---------- */

/** ok = the lookup worked (mph may still be null if the road has no posted limit in the map data). */
data class SpeedLimitResult(val ok: Boolean, val mph: Int?)

object SpeedLimitRepository {
    private const val ROADS =
        "motorway|trunk|primary|secondary|tertiary|unclassified|residential|living_street|" +
            "motorway_link|trunk_link|primary_link|secondary_link|tertiary_link"

    suspend fun fetch(lat: Double, lon: Double): SpeedLimitResult = withContext(Dispatchers.IO) {
        try {
            val query = "[out:json][timeout:8];" +
                "way(around:25,$lat,$lon)[highway~\"^($ROADS)$\"];" +
                "out tags;"
            val conn = URL("https://overpass-api.de/api/interpreter").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 8000
            conn.readTimeout = 10000
            conn.setRequestProperty("User-Agent", "DashLauncher/1.0 (personal car launcher)")
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            conn.outputStream.use { it.write(("data=" + URLEncoder.encode(query, "UTF-8")).toByteArray()) }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()

            val elements = JSONObject(body).getJSONArray("elements")
            if (elements.length() == 0) return@withContext SpeedLimitResult(true, null)
            // Prefer the most major road nearby that has a posted limit.
            val ranked = (0 until elements.length())
                .map { elements.getJSONObject(it).optJSONObject("tags") ?: JSONObject() }
                .sortedBy { rank(it.optString("highway")) }
            val tagged = ranked.firstOrNull { it.has("maxspeed") }
                ?: return@withContext SpeedLimitResult(true, null)
            SpeedLimitResult(true, parse(tagged.optString("maxspeed")))
        } catch (e: Exception) {
            SpeedLimitResult(false, null)
        }
    }

    private fun rank(highway: String): Int = when (highway.removeSuffix("_link")) {
        "motorway" -> 0
        "trunk" -> 1
        "primary" -> 2
        "secondary" -> 3
        "tertiary" -> 4
        else -> 5
    }

    /** "45 mph" -> 45. A bare number is km/h in OpenStreetMap, so convert and round to 5. */
    private fun parse(raw: String): Int? {
        val n = Regex("(\\d+)").find(raw)?.value?.toIntOrNull() ?: return null
        return if (raw.contains("mph", ignoreCase = true)) n
        else ((n * 0.621371) / 5.0).roundToInt() * 5
    }
}

/* ---------- Calendar (whatever is synced to the box's accounts) ---------- */

data class CalendarEvent(val title: String, val begin: Long, val end: Long, val location: String?)

object CalendarRepository {
    fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    /** Next timed event that hasn't ended yet, looking 24 hours ahead. */
    suspend fun nextEvent(context: Context): CalendarEvent? = withContext(Dispatchers.IO) {
        if (!hasPermission(context)) return@withContext null
        try {
            val now = System.currentTimeMillis()
            val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
            ContentUris.appendId(builder, now - 6 * 60 * 60 * 1000L)
            ContentUris.appendId(builder, now + 24 * 60 * 60 * 1000L)
            val projection = arrayOf(
                CalendarContract.Instances.TITLE,
                CalendarContract.Instances.BEGIN,
                CalendarContract.Instances.END,
                CalendarContract.Instances.EVENT_LOCATION,
                CalendarContract.Instances.ALL_DAY,
            )
            context.contentResolver.query(
                builder.build(),
                projection,
                null,
                null,
                CalendarContract.Instances.BEGIN + " ASC",
            )?.use { cursor ->
                while (cursor.moveToNext()) {
                    val allDay = cursor.getInt(4) == 1
                    val end = cursor.getLong(2)
                    if (allDay || end <= now) continue
                    return@withContext CalendarEvent(
                        title = cursor.getString(0)?.takeIf { it.isNotBlank() } ?: "Event",
                        begin = cursor.getLong(1),
                        end = end,
                        location = cursor.getString(3)?.takeIf { it.isNotBlank() },
                    )
                }
            }
            null
        } catch (e: Exception) {
            null
        }
    }
}

/* ---------- Voice commands ---------- */

sealed class VoiceCommand {
    data class Navigate(val place: String) : VoiceCommand()
    data class OpenApp(val name: String) : VoiceCommand()
    data class PlayMusic(val query: String) : VoiceCommand()
    object Play : VoiceCommand()
    object Pause : VoiceCommand()
    object Next : VoiceCommand()
    object Previous : VoiceCommand()
    data class Theme(val mode: String) : VoiceCommand()
    object Parked : VoiceCommand()
    object Forecast : VoiceCommand()
    data class Unknown(val text: String) : VoiceCommand()
}

object VoiceParser {
    private fun after(text: String, vararg prefixes: String): String? {
        for (p in prefixes) {
            if (text.startsWith("$p ")) return text.removePrefix("$p ").trim().takeIf { it.isNotEmpty() }
        }
        return null
    }

    fun parse(raw: String): VoiceCommand {
        val t = raw.trim().lowercase()
        after(t, "navigate to", "take me to", "directions to", "drive to", "go to", "navigate")
            ?.let { return VoiceCommand.Navigate(it) }
        after(t, "open", "launch", "start")?.let { return VoiceCommand.OpenApp(it) }
        when (t) {
            "play", "resume", "play music" -> return VoiceCommand.Play
            "pause", "stop", "pause music", "stop music" -> return VoiceCommand.Pause
            "next", "skip", "next song", "skip song", "next track" -> return VoiceCommand.Next
            "previous", "back", "previous song", "last song", "go back" -> return VoiceCommand.Previous
            "dark mode", "night mode" -> return VoiceCommand.Theme("dark")
            "light mode", "day mode" -> return VoiceCommand.Theme("light")
            "parked mode", "park mode", "theater", "theater mode", "arcade" -> return VoiceCommand.Parked
            "weather", "forecast", "show weather", "show forecast", "what's the weather" -> return VoiceCommand.Forecast
        }
        after(t, "play")?.let { return VoiceCommand.PlayMusic(it.removeSuffix(" on apple music").trim()) }
        return VoiceCommand.Unknown(raw)
    }

    /** Best label match for "open ___". */
    fun findApp(apps: List<AppEntry>, name: String): AppEntry? {
        val n = name.lowercase().replace(" app", "").trim()
        return apps.firstOrNull { it.label.lowercase() == n }
            ?: apps.firstOrNull { it.label.lowercase().startsWith(n) }
            ?: apps.firstOrNull { it.label.lowercase().contains(n) }
            ?: apps.firstOrNull { n.contains(it.label.lowercase()) }
    }
}
