package com.nehls.dashlauncher

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.lerp

/** Top-down pickup, front of the truck at the top. Drawn in code, no image assets. */
@Composable
fun TruckGraphic(modifier: Modifier) {
    val c = LocalDash.current
    val body = c.truckBody
    val glass = if (c.isDark) Color(0xFF16181C) else Color(0xFF101114)
    val tire = Color(0xFF050506)
    val roof = lerp(body, Color.White, 0.12f)
    val bed = lerp(body, Color.Black, 0.45f)
    val rib = lerp(body, Color.Black, 0.30f)
    val glow = c.accent

    Canvas(modifier) {
        var bw = size.height * 0.92f / 2.5f
        if (bw > size.width * 0.5f) bw = size.width * 0.5f
        val bl = bw * 2.5f
        val left = (size.width - bw) / 2f
        val top = (size.height - bl) / 2f
        fun y(f: Float) = top + bl * f
        fun x(f: Float) = left + bw * f

        // soft ground glow
        drawOval(
            brush = Brush.radialGradient(
                colors = listOf(glow.copy(alpha = 0.22f), Color.Transparent),
                center = Offset(size.width / 2f, size.height / 2f),
                radius = bl * 0.62f,
            ),
            topLeft = Offset(left - bw * 0.7f, top - bl * 0.06f),
            size = Size(bw * 2.4f, bl * 1.12f),
        )

        // wheels
        val ww = bw * 0.16f
        val wh = bl * 0.13f
        for (axle in listOf(0.13f, 0.74f)) {
            drawRoundRect(tire, Offset(left - ww * 0.55f, y(axle)), Size(ww, wh), CornerRadius(ww * 0.3f))
            drawRoundRect(tire, Offset(left + bw - ww * 0.45f, y(axle)), Size(ww, wh), CornerRadius(ww * 0.3f))
        }

        // body + mirrors
        drawRoundRect(body, Offset(left, top), Size(bw, bl), CornerRadius(bw * 0.16f))
        drawRoundRect(body, Offset(left - bw * 0.12f, y(0.335f)), Size(bw * 0.14f, bl * 0.035f), CornerRadius(bw * 0.03f))
        drawRoundRect(body, Offset(left + bw * 0.98f, y(0.335f)), Size(bw * 0.14f, bl * 0.035f), CornerRadius(bw * 0.03f))

        // hood creases
        val crease = glass.copy(alpha = 0.3f)
        drawLine(crease, Offset(x(0.28f), y(0.04f)), Offset(x(0.28f), y(0.28f)), strokeWidth = 2f)
        drawLine(crease, Offset(x(0.72f), y(0.04f)), Offset(x(0.72f), y(0.28f)), strokeWidth = 2f)

        // headlights
        val lamp = Color.White.copy(alpha = 0.92f)
        drawRoundRect(lamp, Offset(x(0.07f), y(0.008f)), Size(bw * 0.24f, bl * 0.013f), CornerRadius(4f))
        drawRoundRect(lamp, Offset(x(0.69f), y(0.008f)), Size(bw * 0.24f, bl * 0.013f), CornerRadius(4f))

        // windshield
        val windshield = Path().apply {
            moveTo(x(0.10f), y(0.38f))
            lineTo(x(0.18f), y(0.30f))
            lineTo(x(0.82f), y(0.30f))
            lineTo(x(0.90f), y(0.38f))
            close()
        }
        drawPath(windshield, glass)

        // roof + side glass + rear glass
        drawRoundRect(roof, Offset(x(0.12f), y(0.385f)), Size(bw * 0.76f, bl * 0.17f), CornerRadius(bw * 0.06f))
        drawRect(glass, Offset(x(0.05f), y(0.39f)), Size(bw * 0.05f, bl * 0.16f))
        drawRect(glass, Offset(x(0.90f), y(0.39f)), Size(bw * 0.05f, bl * 0.16f))
        drawRoundRect(glass, Offset(x(0.14f), y(0.565f)), Size(bw * 0.72f, bl * 0.025f), CornerRadius(4f))

        // bed with ribs
        drawRoundRect(bed, Offset(x(0.09f), y(0.62f)), Size(bw * 0.82f, bl * 0.34f), CornerRadius(bw * 0.04f))
        for (i in 1..5) {
            val rx = x(0.09f) + bw * 0.82f * i / 6f
            drawLine(rib, Offset(rx, y(0.635f)), Offset(rx, y(0.945f)), strokeWidth = 2f)
        }

        // tail lights
        val tail = Color(0xFFE5393A)
        drawRect(tail, Offset(left, y(0.90f)), Size(bw * 0.035f, bl * 0.07f))
        drawRect(tail, Offset(x(0.965f), y(0.90f)), Size(bw * 0.035f, bl * 0.07f))
    }
}
