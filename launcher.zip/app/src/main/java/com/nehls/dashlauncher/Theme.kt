package com.nehls.dashlauncher

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

data class DashColors(
    val bg: Color,
    val panel: Color,
    val panelAlt: Color,
    val text: Color,
    val textDim: Color,
    val accent: Color,
    val divider: Color,
    val truckBody: Color,
    val isDark: Boolean,
)

val DarkColors = DashColors(
    bg = Color(0xFF000000),
    panel = Color(0xFF1A1C20),
    panelAlt = Color(0xFF26292F),
    text = Color(0xFFF2F3F5),
    textDim = Color(0xFF8B9099),
    accent = Color(0xFF3E6AE1),
    divider = Color(0xFF24272C),
    truckBody = Color(0xFFD5D8DD),
    isDark = true,
)

val LightColors = DashColors(
    bg = Color(0xFFE9EAEC),
    panel = Color(0xFFFFFFFF),
    panelAlt = Color(0xFFF2F3F5),
    text = Color(0xFF15171A),
    textDim = Color(0xFF6B7079),
    accent = Color(0xFF3E6AE1),
    divider = Color(0xFFD6D8DC),
    truckBody = Color(0xFF3B3F46),
    isDark = false,
)

val LocalDash = staticCompositionLocalOf { DarkColors }
