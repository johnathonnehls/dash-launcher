package com.nehls.dashlauncher

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.osmdroid.config.Configuration

class MainActivity : ComponentActivity() {
    private lateinit var prefs: Prefs
    private lateinit var locationRepo: LocationRepository
    private lateinit var mediaRepo: MediaRepository
    private val ui = UiState()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            ui.hasLocation.value = hasLocationPermission()
            if (ui.hasLocation.value) locationRepo.start()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Configuration.getInstance().load(this, getSharedPreferences("osmdroid", MODE_PRIVATE))
        Configuration.getInstance().userAgentValue = packageName

        prefs = Prefs(this)
        locationRepo = LocationRepository(this)
        mediaRepo = MediaRepository(this)
        ui.themeMode.value = prefs.themeMode
        ui.pinned.value = prefs.pinned
        ui.windowMode.value = prefs.windowMode

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideSystemBars()

        // A launcher never "goes back" anywhere; Back just closes open panels.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                ui.closeOverlays()
            }
        })

        ui.hasLocation.value = hasLocationPermission()
        if (!ui.hasLocation.value && !prefs.askedLocation) requestLocation()

        val actions = DashActions(
            setTheme = { mode ->
                ui.themeMode.value = mode
                prefs.themeMode = mode
            },
            togglePin = { key -> togglePin(key) },
            requestLocation = { requestLocation() },
            openApp = { app, fullScreen ->
                ui.closeOverlays()
                val bounds = if (!fullScreen && ui.windowMode.value) ui.mapBounds.value else null
                AppsLoader.launch(this, app, bounds)
            },
            setWindowMode = { on ->
                ui.windowMode.value = on
                prefs.windowMode = on
            },
        )

        setContent {
            DashApp(ui = ui, location = locationRepo, media = mediaRepo, actions = actions)
        }
    }

    // Start/stop on visibility (not focus) so speed, map and music keep
    // updating while an app is open in a window over the map.
    override fun onStart() {
        super.onStart()
        ui.hasLocation.value = hasLocationPermission()
        if (ui.hasLocation.value) locationRepo.start()
        ui.mediaAccess.value = mediaRepo.hasAccess()
        mediaRepo.start()
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
        reloadApps()
        ui.mediaAccess.value = mediaRepo.hasAccess()
        mediaRepo.start()
    }

    override fun onStop() {
        super.onStop()
        locationRepo.stop()
        mediaRepo.stop()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    // Pressing Home while already home closes the drawer / settings.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        ui.closeOverlays()
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun reloadApps() {
        lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) { AppsLoader.load(this@MainActivity) }
            ui.apps.value = list
            if (!prefs.hasPinned && list.isNotEmpty()) {
                val defaults = AppsLoader.defaultPins(list)
                ui.pinned.value = defaults
                prefs.pinned = defaults
            }
        }
    }

    private fun togglePin(key: String) {
        val list = ui.pinned.value.toMutableList()
        if (list.contains(key)) list.remove(key) else list.add(key)
        ui.pinned.value = list
        prefs.pinned = list
    }

    private fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun requestLocation() {
        if (hasLocationPermission()) return
        val blocked = prefs.askedLocation &&
            !shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)
        if (blocked) {
            // Android won't show the prompt again; send them to the app's settings page.
            DashIntents.openAppDetails(this)
        } else {
            prefs.askedLocation = true
            permissionLauncher.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
            )
        }
    }
}
