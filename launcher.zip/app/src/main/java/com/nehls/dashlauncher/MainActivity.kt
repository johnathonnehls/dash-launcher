package com.nehls.dashlauncher

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.osmdroid.config.Configuration

class MainActivity : ComponentActivity() {
    private lateinit var prefs: Prefs
    private lateinit var locationRepo: LocationRepository
    private lateinit var mediaRepo: MediaRepository
    private val ui = UiState()
    private lateinit var actions: DashActions

    private val calendarPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            ui.hasCalendar.value = CalendarRepository.hasPermission(this)
            if (!it) DashIntents.openAppDetails(this)
        }

    private val voiceLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val heard = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (result.resultCode == RESULT_OK && !heard.isNullOrBlank()) handleVoice(heard)
        }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            ui.hasLocation.value = hasLocationPermission()
            if (ui.hasLocation.value) locationRepo.start()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Configuration.getInstance().load(this, getSharedPreferences("osmdroid", MODE_PRIVATE))
        Configuration.getInstance().userAgentValue = packageName

        prefs = Prefs(this)
        locationRepo = LocationRepository(this)
        mediaRepo = MediaRepository(this)
        ui.themeMode.value = prefs.themeMode
        ui.pinned.value = prefs.pinned
        ui.windowMode.value = prefs.windowMode
        ui.dockStyle.value = prefs.dockStyle
        ui.mapStyle.value = prefs.mapStyle
        ui.dimAtNight.value = prefs.dimAtNight
        ui.hasCalendar.value = CalendarRepository.hasPermission(this)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideSystemBars()

        // A launcher never "goes back" anywhere; Back just closes open panels.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                ui.closeOverlays()
            }
        })

        ui.hasLocation.value = hasLocationPermission()
        if (!ui.hasLocation.value && !prefs.askedLocation) requestLocation()

        actions = DashActions(
            setTheme = { mode ->
                ui.themeMode.value = mode
                prefs.themeMode = mode
            },
            togglePin = { key -> togglePin(key) },
            requestLocation = { requestLocation() },
            openApp = { app, fullScreen ->
                ui.closeOverlays()
                val bounds = if (!fullScreen && ui.windowMode.value) ui.mapBounds.value else null
                AppsLoader.launch(this, app, bounds)
            },
            setWindowMode = { on ->
                ui.windowMode.value = on
                prefs.windowMode = on
            },
            setDockStyle = { style ->
                ui.dockStyle.value = style
                prefs.dockStyle = style
            },
            setMapStyle = { style ->
                ui.mapStyle.value = style
                prefs.mapStyle = style
            },
            setDimAtNight = { on ->
                ui.dimAtNight.value = on
                prefs.dimAtNight = on
            },
            requestCalendar = {
                if (CalendarRepository.hasPermission(this)) ui.hasCalendar.value = true
                else calendarPermission.launch(Manifest.permission.READ_CALENDAR)
            },
            startVoice = { startVoice() },
        )

        setContent {
            DashApp(ui = ui, location = locationRepo, media = mediaRepo, actions = actions)
        }
    }

    // Start/stop on visibility (not focus) so speed, map and music keep
    // updating while an app is open in a window over the map.
    override fun onStart() {
        super.onStart()
        ui.hasCalendar.value = CalendarRepository.hasPermission(this)
        ui.hasLocation.value = hasLocationPermission()
        if (ui.hasLocation.value) locationRepo.start()
        ui.mediaAccess.value = mediaRepo.hasAccess()
        mediaRepo.start()
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
        reloadApps()
        ui.mediaAccess.value = mediaRepo.hasAccess()
        mediaRepo.start()
    }

    override fun onStop() {
        super.onStop()
        locationRepo.stop()
        mediaRepo.stop()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    // Pressing Home while already home closes the drawer / settings.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        ui.closeOverlays()
    }

    private fun startVoice() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Try \"navigate to Sheetz\" or \"play Metro Station\"")
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        try {
            voiceLauncher.launch(intent)
        } catch (e: Exception) {
            toast("Voice needs the Google app installed on the box")
        }
    }

    private fun handleVoice(heard: String) {
        when (val cmd = VoiceParser.parse(heard)) {
            is VoiceCommand.Navigate -> {
                toast("Navigating to ${cmd.place}")
                DashIntents.navigate(this, cmd.place)
            }
            is VoiceCommand.OpenApp -> {
                val app = VoiceParser.findApp(ui.apps.value, cmd.name)
                if (app != null) actions.openApp(app, true) else toast("Couldn't find an app called \"${cmd.name}\"")
            }
            is VoiceCommand.PlayMusic -> {
                toast("Playing ${cmd.query}")
                mediaRepo.playSearch(cmd.query)
            }
            VoiceCommand.Play, VoiceCommand.Pause -> mediaRepo.playPause()
            VoiceCommand.Next -> mediaRepo.next()
            VoiceCommand.Previous -> mediaRepo.previous()
            is VoiceCommand.Theme -> actions.setTheme(cmd.mode)
            VoiceCommand.Parked -> {
                ui.closeOverlays()
                ui.parkedOpen.value = true
            }
            VoiceCommand.Forecast -> {
                ui.closeOverlays()
                ui.forecastOpen.value = true
            }
            is VoiceCommand.Unknown -> toast("Heard \"${cmd.text}\". Try \"navigate to…\", \"play…\" or \"open…\"")
        }
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun reloadApps() {
        lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) { AppsLoader.load(this@MainActivity) }
            ui.apps.value = list
            if (!prefs.hasPinned && list.isNotEmpty()) {
                val defaults = AppsLoader.defaultPins(list)
                ui.pinned.value = defaults
                prefs.pinned = defaults
            }
        }
    }

    private fun togglePin(key: String) {
        val list = ui.pinned.value.toMutableList()
        if (list.contains(key)) list.remove(key) else list.add(key)
        ui.pinned.value = list
        prefs.pinned = list
    }

    private fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun requestLocation() {
        if (hasLocationPermission()) return
        val blocked = prefs.askedLocation &&
            !shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)
        if (blocked) {
            // Android won't show the prompt again; send them to the app's settings page.
            DashIntents.openAppDetails(this)
        } else {
            prefs.askedLocation = true
            permissionLauncher.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
            )
        }
    }
}
