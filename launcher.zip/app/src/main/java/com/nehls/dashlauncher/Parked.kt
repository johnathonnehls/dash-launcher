package com.nehls.dashlauncher

import android.annotation.SuppressLint
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay

/** Full-screen entertainment that only runs while stopped. Closes itself the moment the truck moves. */
@Composable
fun ParkedScreen(moving: Boolean, onClose: () -> Unit) {
    val c = LocalDash.current
    var tab by remember { mutableStateOf("youtube") }

    LaunchedEffect(moving) {
        if (moving) onClose()
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(c.bg)
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Parked", color = c.text, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.width(20.dp))
            listOf("youtube" to "YouTube", "ttt" to "Tic-Tac-Toe", "memory" to "Memory").forEach { (key, label) ->
                val selected = tab == key
                Text(
                    label,
                    color = if (selected) Color.White else c.text,
                    fontSize = 16.sp,
                    modifier = Modifier
                        .padding(end = 8.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (selected) c.accent else c.panel)
                        .clickable { tab = key }
                        .padding(horizontal = 18.dp, vertical = 10.dp),
                )
            }
            Spacer(Modifier.weight(1f))
            Text("Closes automatically when you drive", color = c.textDim, fontSize = 13.sp)
            Spacer(Modifier.width(14.dp))
            RoundButton(Icons.Filled.Close, onClick = onClose)
        }
        Spacer(Modifier.height(14.dp))
        Box(
            Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(18.dp))
                .background(c.panel),
            contentAlignment = Alignment.Center,
        ) {
            when (tab) {
                "youtube" -> YouTubeView(Modifier.fillMaxSize())
                "ttt" -> TicTacToe()
                else -> MemoryGame()
            }
        }
    }
}

/* ---------- YouTube in an embedded browser ---------- */

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubeView(modifier: Modifier) {
    val context = LocalContext.current
    val views = remember {
        val frame = FrameLayout(context)
        val web = WebView(context)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = object : WebViewClient() {
            // Stay in the page; ignore "open in the YouTube app" links.
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val scheme = request?.url?.scheme ?: return false
                return scheme != "http" && scheme != "https"
            }
        }
        var fullScreenView: View? = null
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (view == null) return
                fullScreenView = view
                frame.addView(
                    view,
                    FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT),
                )
            }

            override fun onHideCustomView() {
                fullScreenView?.let { frame.removeView(it) }
                fullScreenView = null
            }
        }
        frame.addView(
            web,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT),
        )
        web.loadUrl("https://m.youtube.com")
        Pair(frame, web)
    }

    DisposableEffect(Unit) {
        onDispose {
            views.second.stopLoading()
            views.second.loadUrl("about:blank")
            views.second.destroy()
        }
    }

    AndroidView(factory = { views.first }, modifier = modifier)
}

/* ---------- Tic-Tac-Toe vs the truck ---------- */

private val LINES = listOf(
    listOf(0, 1, 2), listOf(3, 4, 5), listOf(6, 7, 8),
    listOf(0, 3, 6), listOf(1, 4, 7), listOf(2, 5, 8),
    listOf(0, 4, 8), listOf(2, 4, 6),
)

private fun winner(b: List<String>): String? {
    for (l in LINES) {
        val v = b[l[0]]
        if (v.isNotEmpty() && v == b[l[1]] && v == b[l[2]]) return v
    }
    return if (b.all { it.isNotEmpty() }) "draw" else null
}

private fun cpuMove(b: List<String>): Int? {
    val open = b.indices.filter { b[it].isEmpty() }
    if (open.isEmpty()) return null
    fun completes(mark: String): Int? = open.firstOrNull { i ->
        val t = b.toMutableList()
        t[i] = mark
        winner(t) == mark
    }
    return completes("O") ?: completes("X")
        ?: (if (4 in open) 4 else null)
        ?: listOf(0, 2, 6, 8).filter { it in open }.randomOrNull()
        ?: open.random()
}

@Composable
fun TicTacToe() {
    val c = LocalDash.current
    val board = remember { mutableStateListOf("", "", "", "", "", "", "", "", "") }
    var wins by remember { mutableIntStateOf(0) }
    var losses by remember { mutableIntStateOf(0) }
    val result = winner(board)

    LaunchedEffect(result) {
        when (result) {
            "X" -> wins++
            "O" -> losses++
        }
    }

    Row(Modifier.fillMaxSize().padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(
            Modifier
                .fillMaxHeight()
                .aspectRatio(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            for (r in 0 until 3) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (col in 0 until 3) {
                        val i = r * 3 + col
                        Box(
                            Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(14.dp))
                                .background(c.panelAlt)
                                .clickable(enabled = board[i].isEmpty() && result == null) {
                                    board[i] = "X"
                                    if (winner(board) == null) cpuMove(board)?.let { board[it] = "O" }
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                board[i],
                                color = if (board[i] == "X") c.accent else Color(0xFFE5393A),
                                fontSize = 54.sp,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.width(32.dp))
        Column {
            Text("You are X", color = c.text, fontSize = 20.sp)
            Spacer(Modifier.height(8.dp))
            Text(
                when (result) {
                    "X" -> "You win!"
                    "O" -> "The truck wins."
                    "draw" -> "Draw."
                    else -> "Your move"
                },
                color = c.text,
                fontSize = 28.sp,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(8.dp))
            Text("Wins $wins  ·  Losses $losses", color = c.textDim, fontSize = 15.sp)
            Spacer(Modifier.height(20.dp))
            PillButton("New game") { for (i in board.indices) board[i] = "" }
        }
    }
}

/* ---------- Memory match ---------- */

private val SYMBOLS = listOf(
    "★" to Color(0xFFF5C542), "♥" to Color(0xFFE5393A), "♦" to Color(0xFF3E6AE1),
    "♣" to Color(0xFF34A853), "♠" to Color(0xFFB0B4BB), "●" to Color(0xFFFF8A3D),
    "▲" to Color(0xFF33CCFF), "■" to Color(0xFFB36BFF),
)

@Composable
fun MemoryGame() {
    val c = LocalDash.current
    var deck by remember { mutableStateOf((SYMBOLS.indices + SYMBOLS.indices).shuffled()) }
    val matched = remember { mutableStateListOf<Int>() }
    val faceUp = remember { mutableStateListOf<Int>() }
    var moves by remember { mutableIntStateOf(0) }

    LaunchedEffect(faceUp.size) {
        if (faceUp.size == 2) {
            val (a, b) = faceUp.toList()
            if (deck[a] == deck[b]) {
                matched += listOf(a, b)
                faceUp.clear()
            } else {
                delay(800)
                faceUp.clear()
            }
        }
    }

    Row(Modifier.fillMaxSize().padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(
            Modifier
                .fillMaxHeight()
                .aspectRatio(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            for (r in 0 until 4) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (col in 0 until 4) {
                        val i = r * 4 + col
                        val shown = i in matched || i in faceUp
                        val (symbol, color) = SYMBOLS[deck[i]]
                        Box(
                            Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (shown) c.panelAlt else c.accent.copy(alpha = 0.85f))
                                .border(2.dp, if (i in matched) color.copy(alpha = 0.6f) else Color.Transparent, RoundedCornerShape(12.dp))
                                .clickable(enabled = !shown && faceUp.size < 2) {
                                    faceUp += i
                                    if (faceUp.size == 2) moves++
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            if (shown) Text(symbol, color = color, fontSize = 34.sp)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.width(32.dp))
        Column {
            Text("Find the pairs", color = c.text, fontSize = 20.sp)
            Spacer(Modifier.height(8.dp))
            Text(
                if (matched.size == deck.size) "Done in $moves moves!" else "Moves: $moves",
                color = c.text,
                fontSize = 28.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Start,
            )
            Spacer(Modifier.height(20.dp))
            PillButton("New game") {
                deck = (SYMBOLS.indices + SYMBOLS.indices).shuffled()
                matched.clear()
                faceUp.clear()
                moves = 0
            }
        }
    }
}

@Composable
fun PillButton(label: String, onClick: () -> Unit) {
    val c = LocalDash.current
    Text(
        label,
        color = Color.White,
        fontSize = 16.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier
            .clip(RoundedCornerShape(22.dp))
            .background(c.accent)
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 12.dp),
    )
}
