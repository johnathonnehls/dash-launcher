package com.nehls.dashlauncher

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.app.ActivityOptions
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Rect
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.view.KeyEvent
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

/* ---------- Screen state shared between the activity and the UI ---------- */

class UiState {
    val apps = mutableStateOf<List<AppEntry>>(emptyList())
    val pinned = mutableStateOf<List<String>>(emptyList())
    val themeMode = mutableStateOf("dark")
    val hasLocation = mutableStateOf(false)
    val mediaAccess = mutableStateOf(false)
    val drawerOpen = mutableStateOf(false)
    val settingsOpen = mutableStateOf(false)
    val windowMode = mutableStateOf(true)
    val mapBounds = mutableStateOf<Rect?>(null)

    fun closeOverlays() {
        drawerOpen.value = false
        settingsOpen.value = false
    }
}

class DashActions(
    val setTheme: (String) -> Unit,
    val togglePin: (String) -> Unit,
    val requestLocation: () -> Unit,
    val openApp: (AppEntry, Boolean) -> Unit,   // (app, fullScreen)
    val setWindowMode: (Boolean) -> Unit,
)

const val APPLE_MUSIC = "com.apple.android.music"

object WindowSupport {
    /** True when this Android build allows apps to open in movable/resizable windows. */
    fun isSupported(context: Context): Boolean {
        if (context.packageManager.hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT)) return true
        return try {
            Settings.Global.getInt(context.contentResolver, "enable_freeform_support", 0) != 0
        } catch (e: Exception) {
            false
        }
    }
}

/* ---------- Saved settings ---------- */

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("dash", Context.MODE_PRIVATE)

    var themeMode: String
        get() = sp.getString("theme", "dark") ?: "dark"
        set(value) { sp.edit().putString("theme", value).apply() }

    var pinned: List<String>
        get() = sp.getString("pinned", null)?.split("|")?.filter { it.isNotBlank() } ?: emptyList()
        set(value) { sp.edit().putString("pinned", value.joinToString("|")).apply() }

    val hasPinned: Boolean get() = sp.contains("pinned")

    var windowMode: Boolean
        get() = sp.getBoolean("windowMode", true)
        set(value) { sp.edit().putBoolean("windowMode", value).apply() }

    var askedLocation: Boolean
        get() = sp.getBoolean("askedLocation", false)
        set(value) { sp.edit().putBoolean("askedLocation", value).apply() }
}

/* ---------- Installed apps ---------- */

data class AppEntry(
    val label: String,
    val key: String,
    val component: ComponentName,
    val icon: ImageBitmap,
)

object AppsLoader {
    private val preferredDock = listOf(
        "com.google.android.apps.maps",
        "com.waze",
        APPLE_MUSIC,
        "com.google.android.youtube",
    )

    fun load(context: Context): List<AppEntry> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val px = (64 * context.resources.displayMetrics.density).toInt().coerceIn(48, 192)
        @Suppress("DEPRECATION")
        val activities = pm.queryIntentActivities(intent, 0)
        return activities
            .filter { it.activityInfo.packageName != context.packageName }
            .map { ri ->
                val cn = ComponentName(ri.activityInfo.packageName, ri.activityInfo.name)
                val bmp = try {
                    ri.loadIcon(pm).toBitmap(px, px)
                } catch (e: Exception) {
                    Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
                }
                AppEntry(ri.loadLabel(pm).toString(), cn.flattenToString(), cn, bmp.asImageBitmap())
            }
            .distinctBy { it.key }
            .sortedBy { it.label.lowercase() }
    }

    fun defaultPins(apps: List<AppEntry>): List<String> {
        val picks = preferredDock.mapNotNull { pkg -> apps.firstOrNull { it.component.packageName == pkg }?.key }
        return if (picks.isNotEmpty()) picks.take(6) else apps.take(5).map { it.key }
    }

    /**
     * bounds = screen area to open the app in (the map). On boxes without
     * freeform window support Android ignores it and opens full screen.
     */
    fun launch(context: Context, app: AppEntry, bounds: Rect? = null) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val options = bounds?.let { ActivityOptions.makeBasic().setLaunchBounds(it).toBundle() }
        try {
            context.startActivity(intent, options)
        } catch (e: Exception) {
            try {
                context.startActivity(intent)
            } catch (e2: Exception) {
                DashIntents.launchPackage(context, app.component.packageName)
            }
        }
    }
}

/* ---------- System shortcuts ---------- */

object DashIntents {
    private fun start(context: Context, intent: Intent): Boolean = try {
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    fun navigate(context: Context, query: String) {
        val q = Uri.encode(query)
        val options = listOf(
            Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$q"))
                .setPackage("com.google.android.apps.maps"),
            Intent(Intent.ACTION_VIEW, Uri.parse("waze://?q=$q&navigate=yes")),
            Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$q")),
        )
        for (intent in options) if (start(context, intent)) return
    }

    fun launchPackage(context: Context, pkg: String) {
        context.packageManager.getLaunchIntentForPackage(pkg)?.let { start(context, it) }
    }

    fun openNotificationAccess(context: Context) {
        if (!start(context, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))) {
            start(context, Intent(Settings.ACTION_SETTINGS))
        }
    }

    fun openHomeSettings(context: Context) {
        if (start(context, Intent(Settings.ACTION_HOME_SETTINGS))) return
        if (start(context, Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))) return
        start(context, Intent(Settings.ACTION_SETTINGS))
    }

    fun openDeveloperSettings(context: Context) {
        if (!start(context, Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))) {
            start(context, Intent(Settings.ACTION_SETTINGS))
        }
    }

    fun openStore(context: Context, pkg: String) {
        if (!start(context, Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")))) {
            start(context, Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg")))
        }
    }

    fun openSystemSettings(context: Context) {
        start(context, Intent(Settings.ACTION_SETTINGS))
    }

    fun openAppDetails(context: Context) {
        start(
            context,
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + context.packageName)),
        )
    }

    fun volume(context: Context, up: Boolean) {
        val am = context.getSystemService(AudioManager::class.java) ?: return
        am.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI,
        )
    }

    fun versionName(context: Context): String = try {
        @Suppress("DEPRECATION")
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }
}

/* ---------- Location (GPS speed + map + weather) ---------- */

class LocationRepository(private val context: Context) {
    private val manager = context.getSystemService(LocationManager::class.java)
    private val _location = MutableStateFlow<Location?>(null)
    val location: StateFlow<Location?> = _location
    private var running = false

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            accept(location)
        }

        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

        override fun onProviderEnabled(provider: String) {}

        override fun onProviderDisabled(provider: String) {}
    }

    private fun accept(loc: Location) {
        val current = _location.value
        if (current != null &&
            current.provider == LocationManager.GPS_PROVIDER &&
            loc.provider != LocationManager.GPS_PROVIDER &&
            loc.time - current.time < 10_000
        ) return
        _location.value = loc
    }

    private fun permitted(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun start() {
        if (running || manager == null || !permitted()) return
        for (provider in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
            try {
                if (manager.allProviders.contains(provider)) {
                    manager.requestLocationUpdates(provider, 1000L, 0f, listener, Looper.getMainLooper())
                    if (_location.value == null) manager.getLastKnownLocation(provider)?.let { accept(it) }
                }
            } catch (e: Exception) {
                // provider not allowed on this box; skip it
            }
        }
        running = true
    }

    fun stop() {
        if (!running) return
        try {
            manager?.removeUpdates(listener)
        } catch (e: Exception) {
        }
        running = false
    }
}

/* ---------- Weather (Open-Meteo, no API key) ---------- */

data class Weather(val tempF: Int, val code: Int, val isDay: Boolean)

object WeatherRepository {
    suspend fun fetch(lat: Double, lon: Double): Weather? = withContext(Dispatchers.IO) {
        try {
            val url = URL(
                "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weather_code,is_day&temperature_unit=fahrenheit",
            )
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val current = JSONObject(body).getJSONObject("current")
            Weather(
                tempF = current.getDouble("temperature_2m").roundToInt(),
                code = current.getInt("weather_code"),
                isDay = current.optInt("is_day", 1) == 1,
            )
        } catch (e: Exception) {
            null
        }
    }
}

/* ---------- Now playing (needs notification access) ---------- */

class MediaListenerService : NotificationListenerService()

data class NowPlaying(
    val title: String?,
    val artist: String?,
    val art: Bitmap?,
    val isPlaying: Boolean,
    val packageName: String?,
)

class MediaRepository(private val context: Context) {
    private val _state = MutableStateFlow<NowPlaying?>(null)
    val state: StateFlow<NowPlaying?> = _state

    private val sessionManager = context.getSystemService(MediaSessionManager::class.java)
    private val component = ComponentName(context, MediaListenerService::class.java)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var controller: MediaController? = null
    private var listening = false

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            publish()
        }

        override fun onPlaybackStateChanged(state: PlaybackState?) {
            publish()
        }

        override fun onSessionDestroyed() {
            controller = null
            refresh()
        }
    }

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        attach(pick(list))
    }

    fun hasAccess(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    fun start() {
        if (!hasAccess() || sessionManager == null) {
            _state.value = null
            return
        }
        try {
            if (!listening) {
                sessionManager.addOnActiveSessionsChangedListener(sessionsListener, component)
                listening = true
            }
            refresh()
        } catch (e: SecurityException) {
            _state.value = null
        }
    }

    fun stop() {
        try {
            if (listening) sessionManager?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (e: Exception) {
        }
        listening = false
        controller?.unregisterCallback(callback)
        controller = null
    }

    private fun refresh() {
        try {
            attach(pick(sessionManager?.getActiveSessions(component)))
        } catch (e: SecurityException) {
            attach(null)
        }
    }

    // Only Apple Music is shown and controlled for now.
    private fun pick(list: List<MediaController>?): MediaController? =
        list?.firstOrNull { it.packageName == APPLE_MUSIC }

    private fun attach(next: MediaController?) {
        if (next != null && next.sessionToken == controller?.sessionToken) {
            publish()
            return
        }
        controller?.unregisterCallback(callback)
        controller = next
        next?.registerCallback(callback, mainHandler)
        publish()
    }

    private fun publish() {
        val c = controller
        if (c == null) {
            _state.value = null
            return
        }
        val m = c.metadata
        _state.value = NowPlaying(
            title = m?.getString(MediaMetadata.METADATA_KEY_TITLE),
            artist = m?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: m?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST),
            art = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART),
            isPlaying = c.playbackState?.state == PlaybackState.STATE_PLAYING,
            packageName = c.packageName,
        )
    }

    fun playPause() {
        val c = controller
        if (c == null) {
            sendToAppleMusic(KeyEvent.KEYCODE_MEDIA_PLAY)
            return
        }
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
        else c.transportControls.play()
    }

    fun next() {
        val c = controller
        if (c != null) c.transportControls.skipToNext() else sendToAppleMusic(KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    fun previous() {
        val c = controller
        if (c != null) c.transportControls.skipToPrevious() else sendToAppleMusic(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    /** When Apple Music has no active session yet, wake it with a media button press aimed only at it. */
    private fun sendToAppleMusic(code: Int) {
        for (action in listOf(KeyEvent.ACTION_DOWN, KeyEvent.ACTION_UP)) {
            val intent = Intent(Intent.ACTION_MEDIA_BUTTON)
                .setPackage(APPLE_MUSIC)
                .putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(action, code))
            try {
                context.sendBroadcast(intent)
            } catch (e: Exception) {
            }
        }
    }
}
