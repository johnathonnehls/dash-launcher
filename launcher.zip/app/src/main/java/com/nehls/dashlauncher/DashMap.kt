package com.nehls.dashlauncher

import android.location.LocationManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay

private const val ATTRIBUTION = "© OpenStreetMap contributors © CARTO"

private val DarkTiles = XYTileSource(
    "CartoDark", 1, 19, 256, ".png",
    arrayOf(
        "https://a.basemaps.cartocdn.com/dark_all/",
        "https://b.basemaps.cartocdn.com/dark_all/",
        "https://c.basemaps.cartocdn.com/dark_all/",
    ),
    ATTRIBUTION,
)

private val LightTiles = XYTileSource(
    "CartoVoyager", 1, 19, 256, ".png",
    arrayOf(
        "https://a.basemaps.cartocdn.com/rastertiles/voyager/",
        "https://b.basemaps.cartocdn.com/rastertiles/voyager/",
        "https://c.basemaps.cartocdn.com/rastertiles/voyager/",
    ),
    ATTRIBUTION,
)

@Composable
fun DashMap(modifier: Modifier, isDark: Boolean, hasLocation: Boolean, recenterSignal: Int) {
    val context = LocalContext.current
    val mapView = remember {
        MapView(context).apply {
            setTileSource(if (isDark) DarkTiles else LightTiles)
            setMultiTouchControls(true)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            setTilesScaledToDpi(true)
            setMinZoomLevel(3.0)
            setMaxZoomLevel(19.0)
            controller.setZoom(4.5)
            controller.setCenter(GeoPoint(39.8, -98.6))
        }
    }
    val overlayHolder = remember { mutableStateOf<MyLocationNewOverlay?>(null) }

    LaunchedEffect(isDark) {
        mapView.setTileSource(if (isDark) DarkTiles else LightTiles)
    }

    LaunchedEffect(hasLocation) {
        if (hasLocation && overlayHolder.value == null) {
            val provider = GpsMyLocationProvider(context)
            provider.addLocationSource(LocationManager.NETWORK_PROVIDER)
            val overlay = MyLocationNewOverlay(provider, mapView)
            overlay.enableMyLocation()
            overlay.enableFollowLocation()
            overlay.runOnFirstFix {
                mapView.post {
                    mapView.controller.setZoom(16.0)
                    overlay.myLocation?.let { mapView.controller.animateTo(it) }
                }
            }
            mapView.overlays.add(overlay)
            overlayHolder.value = overlay
        }
    }

    LaunchedEffect(recenterSignal) {
        if (recenterSignal == 0) return@LaunchedEffect
        overlayHolder.value?.let { overlay ->
            overlay.enableFollowLocation()
            overlay.myLocation?.let {
                mapView.controller.setZoom(16.0)
                mapView.controller.animateTo(it)
            }
        }
    }

    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> {
                    mapView.onResume()
                    overlayHolder.value?.enableMyLocation()
                }
                Lifecycle.Event.ON_STOP -> {
                    mapView.onPause()
                    overlayHolder.value?.disableMyLocation()
                }
                else -> {}
            }
        }
        lifecycle.addObserver(observer)
        onDispose {
            lifecycle.removeObserver(observer)
            mapView.onDetach()
        }
    }

    AndroidView(factory = { mapView }, modifier = modifier)
}
