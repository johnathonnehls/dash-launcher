package com.nehls.dashlauncher

import android.graphics.Color as AndroidColor
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.location.LocationManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.MapTileIndex
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay

// OpenStreetMap's own tiles: free, no API key. Dark mode is the same map
// recolored on the device (desaturate, invert, dim with a slight blue cast).
private val DarkFilter: ColorMatrixColorFilter = run {
    val m = ColorMatrix().apply { setSaturation(0.15f) }
    m.postConcat(
        ColorMatrix(
            floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f,
            ),
        ),
    )
    m.postConcat(
        ColorMatrix(
            floatArrayOf(
                0.60f, 0f, 0f, 0f, 6f,
                0f, 0.64f, 0f, 0f, 9f,
                0f, 0f, 0.72f, 0f, 16f,
                0f, 0f, 0f, 1f, 0f,
            ),
        ),
    )
    ColorMatrixColorFilter(m)
}

// "Mars" easter egg: the street map recolored in rusty reds and tans.
private val MarsFilter: ColorMatrixColorFilter = run {
    val m = ColorMatrix().apply { setSaturation(0f) }
    m.postConcat(
        ColorMatrix(
            floatArrayOf(
                0.85f, 0f, 0f, 0f, 40f,
                0.45f, 0f, 0f, 0f, 14f,
                0.25f, 0f, 0f, 0f, 6f,
                0f, 0f, 0f, 1f, 0f,
            ),
        ),
    )
    ColorMatrixColorFilter(m)
}

// Satellite photos from USGS (US government, free, no key). Its tile order is zoom/y/x.
private val UsgsImagery = object : OnlineTileSourceBase(
    "USGSImagery", 0, 16, 256, "",
    arrayOf("https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryOnly/MapServer/tile/"),
    "USGS The National Map",
) {
    override fun getTileURLString(pMapTileIndex: Long): String =
        baseUrl + MapTileIndex.getZoom(pMapTileIndex) + "/" +
            MapTileIndex.getY(pMapTileIndex) + "/" + MapTileIndex.getX(pMapTileIndex)
}

private fun applyMapTheme(mapView: MapView, isDark: Boolean, style: String = "standard") {
    val tiles = mapView.overlayManager.tilesOverlay
    if (style == "satellite") {
        mapView.setTileSource(UsgsImagery)
        mapView.setMaxZoomLevel(16.0)
        if (mapView.zoomLevelDouble > 16.0) mapView.controller.setZoom(16.0)
    } else {
        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.setMaxZoomLevel(19.0)
    }
    tiles.setColorFilter(
        when (style) {
            "satellite" -> null
            "mars" -> MarsFilter
            else -> if (isDark) DarkFilter else null
        },
    )
    tiles.setLoadingBackgroundColor(if (isDark) AndroidColor.rgb(18, 20, 24) else AndroidColor.rgb(230, 230, 230))
    tiles.setLoadingLineColor(if (isDark) AndroidColor.rgb(30, 33, 38) else AndroidColor.rgb(215, 215, 215))
    mapView.invalidate()
}

@Composable
fun DashMap(modifier: Modifier, isDark: Boolean, style: String, hasLocation: Boolean, recenterSignal: Int) {
    val context = LocalContext.current
    val mapView = remember {
        MapView(context).apply {
            applyMapTheme(this, isDark, style)
            setMultiTouchControls(true)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            setTilesScaledToDpi(true)
            setMinZoomLevel(3.0)
            controller.setZoom(4.5)
            controller.setCenter(GeoPoint(39.8, -98.6))
        }
    }
    val overlayHolder = remember { mutableStateOf<MyLocationNewOverlay?>(null) }

    LaunchedEffect(isDark, style) {
        applyMapTheme(mapView, isDark, style)
    }

    LaunchedEffect(hasLocation) {
        if (hasLocation && overlayHolder.value == null) {
            val provider = GpsMyLocationProvider(context)
            provider.addLocationSource(LocationManager.NETWORK_PROVIDER)
            val overlay = MyLocationNewOverlay(provider, mapView)
            overlay.enableMyLocation()
            overlay.enableFollowLocation()
            overlay.runOnFirstFix {
                mapView.post {
                    mapView.controller.setZoom(16.0)
                    overlay.myLocation?.let { mapView.controller.animateTo(it) }
                }
            }
            mapView.overlays.add(overlay)
            overlayHolder.value = overlay
        }
    }

    LaunchedEffect(recenterSignal) {
        if (recenterSignal == 0) return@LaunchedEffect
        overlayHolder.value?.let { overlay ->
            overlay.enableFollowLocation()
            overlay.myLocation?.let {
                mapView.controller.setZoom(16.0)
                mapView.controller.animateTo(it)
            }
        }
    }

    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> {
                    mapView.onResume()
                    overlayHolder.value?.enableMyLocation()
                }
                Lifecycle.Event.ON_STOP -> {
                    mapView.onPause()
                    overlayHolder.value?.disableMyLocation()
                }
                else -> {}
            }
        }
        lifecycle.addObserver(observer)
        onDispose {
            lifecycle.removeObserver(observer)
            mapView.onDetach()
        }
    }

    AndroidView(factory = { mapView }, modifier = modifier)
}
